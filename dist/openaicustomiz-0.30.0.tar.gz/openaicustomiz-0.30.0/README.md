# OpenAI Python Library Customed

The OpenAI Python library orginially made by openai and was customed to be used in https://zhouzhuzheng-chatgpt.streamlit.app/

## Installation via pypi


```sh
pip install openaicustomiz
```
